package com.example.dass_21;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.textfield.TextInputLayout;

import java.util.regex.Pattern;

public class CrearContrasena extends AppCompatActivity {

    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    "(?=\\S+$)" +
                    ".{4,}" +
                    "$");
    private TextInputLayout password;
    private TextInputLayout passwordConfirm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_contrasena);

        passwordConfirm = findViewById(R.id.passwordConfirm);
        password = findViewById(R.id.password);
    }

    private boolean validatePassword() {
        String passwordInput = password.getEditText().getText().toString().trim();

        if (passwordInput.isEmpty()) {
            password.setError("Este campo es obligatorio");
            return false;
        }
        else if (!PASSWORD_PATTERN.matcher(passwordInput).matches()) {
            password.setError("La contraseña es débil");
            return false;
        }
        else {
            password.setError(null);;
            return true;
        }
    }

    private boolean validatePasswordconf() {
        String passwordconf = passwordConfirm.getEditText().getText().toString().trim();

        if (passwordconf.isEmpty()) {
            passwordConfirm.setError("Este campo es obligatorio");
            return false;
        }
        else if (!PASSWORD_PATTERN.matcher(passwordconf).matches()) {
            passwordConfirm.setError("La contraseña es débil");
            return false;
        }
        else {
            passwordConfirm.setError(null);
            return true;
        }
    }

    public void confirmInput(View v) {
        if (!validatePassword()| !validatePasswordconf()) {
            return;
        }
        Intent validar = new Intent(this, MainActivity.class);
        startActivity(validar);
    }

    public void carcelar (View view){
        Intent cancel= new Intent(this,MainActivity.class );
        startActivity(cancel);
    }
}