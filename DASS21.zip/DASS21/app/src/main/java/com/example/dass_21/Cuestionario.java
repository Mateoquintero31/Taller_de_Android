package com.example.dass_21;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Cuestionario extends AppCompatActivity {

    private int ids_respuestas1[] ={
            R.id.respuesta1, R.id.respuesta2, R.id.respuesta3, R.id.respuesta4
    };
    private String[] preguntas;
    private int preguntaActual;
    private TextView txtPregunta1;
    private RadioGroup group;
    private RadioButton respuesta1, respuesta2, respuesta3, respuesta4;
    private int [] resp;
    private Button btnSiguiente, btnAnterior;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuestionario);

        txtPregunta1 = (TextView) findViewById(R.id.txtPregunta1);
        group = (RadioGroup) findViewById(R.id.rgRespuestas);
        btnSiguiente = (Button) findViewById(R.id.btnSiguiente);
        btnAnterior = (Button) findViewById(R.id.btnAnterior);
        respuesta1 = (RadioButton) findViewById(R.id.respuesta1);
        respuesta2 = (RadioButton) findViewById(R.id.respuesta2);
        respuesta3 = (RadioButton) findViewById(R.id.respuesta3);
        respuesta4 = (RadioButton) findViewById(R.id.respuesta4);

        preguntas = getResources().getStringArray(R.array.preguntas);
        resp = new int[preguntas.length];
        for (int i = 0; i < resp.length; i++){
            resp [i] = -1;
        }
        preguntaActual = 0;
        mostrarPregunta();

        btnSiguiente.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int id = group.getCheckedRadioButtonId();
                int index = -1;
                for (int i = 0; i <ids_respuestas1.length; i++){
                    if (ids_respuestas1[i] == id ){
                        index = i;
                    }
                }
                resp [preguntaActual] = index;

                if (respuesta1.isChecked()==false && respuesta2.isChecked()==false && respuesta3.isChecked()==false && respuesta4.isChecked()==false){
                    Toast.makeText(Cuestionario.this, "Seleccione una opción", Toast.LENGTH_SHORT).show();
                } else if (preguntaActual < preguntas.length-1){
                    preguntaActual++;
                    mostrarPregunta();
                }
            }
        });
        btnAnterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (preguntaActual > 0){
                    preguntaActual--;
                    mostrarPregunta();
                }
            }
        });
    }

    private void mostrarPregunta () {
        String q = preguntas[preguntaActual];
        String[] parts = q.split(";");

        group.clearCheck();
        txtPregunta1.setText(parts[0]);
        for (int i = 0; i < ids_respuestas1.length; i++) {
            RadioButton res1 = (RadioButton) findViewById(ids_respuestas1[i]);
            res1.setText(parts[i+1]);
        }
        if (preguntaActual == 0 ){
            btnAnterior.setVisibility(View.GONE);
        }else{
            btnAnterior.setVisibility(View.VISIBLE);
        }
        if (preguntaActual == preguntas.length-1){
            btnSiguiente.setText(R.string.terminar);
            Intent resultado= new Intent(this,Resultados.class );
            startActivity(resultado);
        }else{
            btnSiguiente.setText(R.string.Siguiente);
        }
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

        @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}