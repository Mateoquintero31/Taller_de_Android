package com.example.dass_21;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;

public class IngresarDatos extends AppCompatActivity {

    private Spinner spinner1;
    TextView tv, efecha, txtEstadoCivil;
    RadioButton r1, r2, radioButtonMasculino;
    EditText txtNombreCompleto, txtNumeroIdentificacion, TxtEdad, txtDireccionResidencia, txtCiudadResidencia,
            TxtTelefonoContacto, txtOcupacion, txtEPS, TxtEmail, TxtContactoEmergencia;
    RadioGroup rgGenero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingresar_datos);

        txtNombreCompleto = (EditText) findViewById(R.id.txtNombreCompleto);
        txtNumeroIdentificacion = (EditText) findViewById(R.id.txtNumeroIdentificacion);
        TxtEdad = (EditText) findViewById(R.id.TxtEdad);
        txtDireccionResidencia = (EditText) findViewById(R.id.txtDireccionResidencia);
        txtCiudadResidencia = (EditText) findViewById(R.id.txtCiudadResidencia);
        TxtTelefonoContacto = (EditText) findViewById(R.id.TxtTelefonoContacto);
        txtOcupacion = (EditText) findViewById(R.id.txtOcupacion);
        txtEPS = (EditText) findViewById(R.id.txtEPS);
        TxtEmail = (EditText) findViewById(R.id.TxtEmail);
        TxtContactoEmergencia = (EditText) findViewById(R.id.TxtContactoEmergencia);
        efecha = (TextView) findViewById(R.id.efecha);
        txtEstadoCivil = (TextView) findViewById(R.id.txtEstadoCivil);
        r1 = (RadioButton) findViewById(R.id.radioButtonFemenino);
        r2 = (RadioButton) findViewById(R.id.radioButtonMasculino);
        tv = findViewById(R.id.efecha);
        rgGenero = (RadioGroup) findViewById(R.id.rgGenero);


        //Lista de opciones del tipo de regimen SS
        spinner1 = (Spinner) findViewById(R.id.spnRegimen);
        String[] opcionesRegimen = {"Contributivo", "Subsidiado", "Excepción", "Especial", "No afiliado"};

        ArrayAdapter<String> adp1 = new ArrayAdapter<String>(IngresarDatos.this, android.R.layout.simple_spinner_dropdown_item, opcionesRegimen);
        spinner1.setAdapter(adp1);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Button btnGuardar = (Button) findViewById(R.id.btnGuardar);

        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validar();
            }
        });

    }

            @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case android.R.id.home:
                    finish();
                    return true;
            }
            return super.onOptionsItemSelected(item);
    }

    public void abrirCalendario (View view){
        Calendar cal = Calendar.getInstance();
        int anio = cal.get(Calendar.YEAR);
        int mes = cal.get(Calendar.MONTH);
        int dia = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dpd = new DatePickerDialog(IngresarDatos.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                String fecha = dayOfMonth + "/" + month + "/" + year;
                tv.setText(fecha);
            }
        }, anio, mes, dia);
        dpd.show();
    }
    private boolean validar() {
        txtNombreCompleto.setError(null);
        txtNumeroIdentificacion.setError(null);
        TxtEdad.setError(null);
        txtDireccionResidencia.setError(null);
        txtCiudadResidencia.setError(null);
        TxtTelefonoContacto.setError(null);
        txtOcupacion.setError(null);
        txtEPS.setError(null);
        TxtEmail.setError(null);
        TxtContactoEmergencia.setError(null);

        String nombrecompleto = txtNombreCompleto.getText().toString();
        String numeroIdentificacion = txtNumeroIdentificacion.getText().toString();
        String fechaNacimiento = efecha.getText().toString();
        String estadoCivil = txtEstadoCivil.getText().toString();
        String edad = TxtEdad.getText().toString();
        String direccionResidencia = txtDireccionResidencia.getText().toString();
        String ciudad = txtCiudadResidencia.getText().toString();
        String tel = TxtTelefonoContacto.getText().toString();
        String telemerg = TxtContactoEmergencia.getText().toString();
        String EPS = txtEPS.getText().toString();
        String ocupacion = txtOcupacion.getText().toString();
        String email = TxtEmail.getText().toString();

        if (TextUtils.isEmpty(nombrecompleto)) {
            txtNombreCompleto.setError(getString(R.string.error_campo_obligatorio));
            txtNombreCompleto.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(numeroIdentificacion)) {
            txtNumeroIdentificacion.setError(getString(R.string.error_campo_obligatorio));
            txtNumeroIdentificacion.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(fechaNacimiento)) {
            efecha.setError(getString(R.string.error_campo_obligatorio));
            efecha.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(edad)) {
            TxtEdad.setError(getString(R.string.error_campo_obligatorio));
            TxtEdad.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(estadoCivil)) {
            txtEstadoCivil.setError(getString(R.string.error_campo_obligatorio));
            txtEstadoCivil.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(direccionResidencia)) {
            txtDireccionResidencia.setError(getString(R.string.error_campo_obligatorio));
            txtDireccionResidencia.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(ciudad)) {
            txtCiudadResidencia.setError(getString(R.string.error_campo_obligatorio));
            txtCiudadResidencia.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(tel)) {
            TxtTelefonoContacto.setError(getString(R.string.error_campo_obligatorio));
            TxtTelefonoContacto.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(ocupacion)) {
            txtOcupacion.setError(getString(R.string.error_campo_obligatorio));
            txtOcupacion.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(EPS)) {
            txtEPS.setError(getString(R.string.error_campo_obligatorio));
            txtEPS.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(email)) {
            TxtEmail.setError(getString(R.string.error_campo_obligatorio));
            TxtEmail.requestFocus();
            return false;
        }
        if (TextUtils.isEmpty(telemerg)) {
            TxtContactoEmergencia.setError(getString(R.string.error_campo_obligatorio));
            TxtContactoEmergencia.requestFocus();
            return false;
        }
        Intent password= new Intent(this, CrearContrasena.class);
        startActivity(password);
        return false;
    }
}