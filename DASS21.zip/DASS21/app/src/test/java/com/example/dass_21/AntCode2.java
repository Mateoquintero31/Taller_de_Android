package com.example.dass_21;

public class AntCode2 {
}
